package Practica2;

import java.util.ArrayList;

public class Prueba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Producto p = new Producto(5.0, "KitKat", "111111111117");
		Producto q = new Producto(5.0, "KitKat", "123456789128");
		ArrayList<Producto> array = new ArrayList<>();
		array.add(p);
		//array.add(q);
		Pack illo = new Pack("prueba", "illoillo", array);
		Vendible v = p;
		Vendible u = illo;

		System.out.println(v.getPrecio());
		System.out.println(illo);
		illo.agregarProducto(q);
	}
}
