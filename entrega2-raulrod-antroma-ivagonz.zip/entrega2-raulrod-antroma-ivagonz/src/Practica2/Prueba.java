package Practica2;

public class Prueba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Producto p = new Producto(5.0, "KitKat", "111111111117");
		Producto q = new Producto(5.0, "KitKat", "123456789128");
		Producto[] array = new Producto[3];
		array[0] = q;
		array[1] = p;
		Pack illo = new Pack("prueba", "illoillo", array);
		Vendible v = p;
		Vendible u = illo;

		System.out.println(v.getPrecio());
		System.out.println(u.getPrecio());
		illo.agregarProducto(new Producto(5.0, "KitKat", "111111111128"));
	}

}
