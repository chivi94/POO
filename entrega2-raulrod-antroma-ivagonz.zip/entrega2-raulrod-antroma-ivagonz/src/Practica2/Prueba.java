package Practica2;

public class Prueba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Producto p = new Producto(2.0, "KitKat", "111111111117");

		if (p instanceof Vendible) {
			System.out.println(p.getId());
		}

	}

}
