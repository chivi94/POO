package Practica2;

/**
 * Implementacion abstracta de un Vendible. Se podra consultar su informacion.
 * 
 * Segunda parte de la practica para la asignatura de Programacion Orientada a
 * Objetos. Escuela de Ingenieria Informatica, Universidad de Valladolid.
 * 
 * @author raulrod antroma ivagonz
 * 
 */
public abstract class Vendible {

	private String nombre;
	private String id;

	public Vendible() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Inicializacion de un objeto tipo Vendible con nombre e identificador
	 * 
	 * @param nombre
	 *            Nombre del Producto.
	 * @param id
	 *            Cadena que identifica al Vendible.
	 * @throws IllegalArgumentException
	 *             Si se incumplen las condiciones impuestas a los parametros.
	 */
	public Vendible(String nombre, String id) {
		super();

		if (nombre == null) {
			throw new IllegalArgumentException("No se ha introducido nombre.");
		}

		if (nombre.isEmpty()) {
			throw new IllegalArgumentException("El nombre es una cadena vacia.");
		}

		if (id == null) {
			throw new IllegalArgumentException("No se ha introducido id.");
		}

		if (id.isEmpty()) {
			throw new IllegalArgumentException("El id es una cadena vacia.");
		}
		this.nombre = nombre;
		this.id = id;
	}

	/**
	 * 
	 * Compara dos objetos
	 * 
	 * @param obj
	 *            obejto a comparar con el actual, debera ser instancia de la
	 *            clase vendible Y comparara entre este y this sus
	 *            identificadores para determinar si son iguales o no
	 * 
	 * @return true si los identificadores son iguales, o false en caso
	 *         contrario
	 * 
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Vendible) {
			Vendible v = (Vendible) obj;
			return getId() == v.getId();
		}
		return false;
	}

	/**
	 * 
	 * @return precio asociado al Vendible
	 */
	public abstract double getPrecio();

	/**
	 * @return nombre asociado al Vendible.
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @return id asociado al Vendible.
	 */
	public String getId() {
		return id;
	}

}
