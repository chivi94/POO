package Practica2;

public abstract class Vendible {

	private String nombre;
	private String id;
	private double precio;

	public Vendible() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Inicialización de un objeto tipo Vendible con nombre, identificador y
	 * precio
	 * 
	 * @param precio
	 *            Valor del Producto. Debe ser mayor o igual que 0, con 2
	 *            decimales como máximo.
	 * @param nombre
	 *            Nombre del Producto.
	 * @param id
	 *            Cadena que identifica al Vendible.
	 * @throws IllegalArgumentException
	 *             Si se incumplen las condiciones impuestas a los parámetros.
	 */
	public Vendible(String nombre, String id, double precio) {
		super();
		if (precio <= 0) {
			throw new IllegalArgumentException("Precio menor o igual que cero.");
		}
		if (!comprobarDecimalesPrecio(precio)) {
			throw new IllegalArgumentException("Precio con más de 2 decimales.");
		}

		if (nombre == null) {
			throw new IllegalArgumentException("No se ha introducido nombre.");
		}

		if (nombre.isEmpty()) {
			throw new IllegalArgumentException("El nombre es una cadena vacía.");
		}
		this.nombre = nombre;
		this.id = id;
		this.precio = precio;
	}

	/**
	 * Metodo que comprobara si el precio pasado como argumento es correcto o
	 * no. Para ser considerado correcto deberá tener como mucho 2 decimales.
	 * 
	 * @param precio
	 *            Valor real que representa el precio del Producto.
	 * @return True si el precio es correcto(maximo 2 decimales), False en caso
	 *         contrario.
	 */
	public static boolean comprobarDecimalesPrecio(double precio) {
		boolean correcto = true;
		int precioEntero = (int) (precio * 100);
		if ((precio * 100) - precioEntero != 0) {
			correcto = false;
		}
		return correcto;
	}

	public abstract double getPrecio();

	public abstract void setPrecio(double precio);

	public String getNombre() {
		return nombre;
	}

	public String getId() {
		return id;
	}

}
