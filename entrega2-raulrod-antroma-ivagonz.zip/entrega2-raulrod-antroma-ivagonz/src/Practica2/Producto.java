package Practica2;

/**
 * Implementacion de un Producto. Se podra consultar su informacion.
 * 
 * Segunda parte de la practica para la asignatura de Programacion Orientada a
 * Objetos. Escuela de Ingenieria Informatica, Universidad de Valladolid.
 * 
 * @author raulrod antroma ivagonz
 * 
 */

public class Producto extends Vendible {
	private String upc;
	private double precio;

	/**
	 * Inicializacion con precio, nombre de producto e identificador.
	 * 
	 * @see Practica2.Vendible#Vendible(String nombre, String identificador)
	 * 
	 * @param precio
	 *            Valor del producto, debe ser mayor que cero, y que tenga como
	 *            maximo dos decimales.
	 * 
	 * @param upc
	 *            Cadena que identifica el Producto. Deber ser correcto. Es
	 *            correcto si: Tiene 12 caracteres y el digito numero 12 es
	 *            correcto(esta obtenido a partir del resto).
	 * @throws IllegalArgumentException
	 *             Si se incumplen las condiciones impuestas a los parametros.
	 */
	public Producto(double precio, String nombre, String upc) {
		super(nombre, upc);

		if (!comprobarDigitoControl(upc)) {
			throw new IllegalArgumentException("Digito de control no valido.");
		}
		if (!comprobarUpc(upc)) {
			throw new IllegalArgumentException("Caracter incorrecto dentro del UPC.");
		}
		if (upc.length() != 12) {
			throw new IllegalArgumentException("Longitud de identificador distinta a 12");
		}
		if (precio <= 0) {
			throw new IllegalArgumentException("Precio menor o igual que cero.");
		}
		if (!comprobarDecimalesPrecio(precio)) {
			throw new IllegalArgumentException("Precio con mas de 2 decimales.");
		}

		this.upc = upc;
		this.precio = precio;
	}

	/**
	 * Metodo que comprobara si el digito de control del producto es correcto o
	 * no. Para ser correcto debera cumplir las siguientes restricciones: 1. El
	 * ultimo digito debera depender del resto.
	 * 
	 * @param upc
	 *            Identificador del producto.
	 * @return True si el identificador es correcto, False en caso contrario.
	 */
	public static boolean comprobarDigitoControl(String upc) {
		// Valor ascii para obtener la cifra decimal correcta
		int ascii = 48;
		// Digito de control del upc del producto
		int control = ((int) upc.charAt(upc.length() - 1)) - ascii;
		// Resultado de la suma de la obtencion del upc
		int s = 0;
		// Variable usada para almacenar el digito del upc
		int caracter = 0;
		// Variable usada para obtener el digito de control
		int resto = 0;
		// Digito de control obtenido al final de la ejecucion de todo el codigo
		int d = 0;

		boolean correcto = false;
		for (int i = 0; i < upc.length() - 1; i++) {
			caracter = ((int) upc.charAt(i)) - ascii;
			if (i % 2 == 0) {
				s += caracter * 3;
			} else {
				s += caracter;
			}
		}
		resto = s % 10;
		d = 10 - resto;
		if (d == control) {
			correcto = true;
		}

		return correcto;
	}

	// Comprueba si el Upc tiene algun caracter que no sea un numero
	/**
	 * Metodo que comprueba si el identificador de producto es correcto o no.
	 * Para considerarlo correcto debera cumplir que todos sus componentes sean
	 * digitos.
	 * 
	 * @param upc
	 *            Identificador del producto.
	 * @return True si el identificador es correcto, False en caso contrario.
	 */
	public static boolean comprobarUpc(String upc) {
		boolean correcto = true;
		int caracter = 0;
		int ascii = 48;
		int i = 0;
		while (correcto && i < upc.length()) {
			caracter = ((int) upc.charAt(i)) - ascii;
			if (caracter < 0 || caracter > 9) {
				correcto = false;
			}
			i++;
		}
		return correcto;
	}

	/**
	 * Metodo que comprobara si el precio pasado como argumento es correcto o
	 * no. Para ser considerado correcto debera tener como mucho 2 decimales.
	 * 
	 * @param precio
	 *            Valor real que representa el precio del Producto.
	 * @return True si el precio es correcto(maximo 2 decimales), False en caso
	 *         contrario.
	 */
	public static boolean comprobarDecimalesPrecio(double precio) {
		boolean correcto = true;
		int precioEntero = (int) (precio * 100);
		if ((precio * 100) - precioEntero != 0) {
			correcto = false;
		}
		return correcto;
	}

	/**
	 * @see Practica2.Vendible#getPrecio()
	 * @return precio asociado al Producto.
	 */
	@Override
	public double getPrecio() {
		return precio;
	}

	/**
	 * 
	 * @return upc asociado al Producto.
	 */
	public String getUpc() {
		return upc;
	}

	/**
	 * Permite modificar el precio del Producto.
	 * 
	 * @param precio
	 *            Nuevo valor del Producto. Debe ser mayor de 0 y tener 2
	 *            decimales.
	 */
	public void setPrecio(double precio) {
		if (precio <= 0) {
			throw new IllegalArgumentException("Precio menor o igual que cero.");
		}
		if (!comprobarDecimalesPrecio(precio)) {
			throw new IllegalArgumentException("Precio con mas de 2 decimales.");
		}
		this.precio = precio;
	}

}
