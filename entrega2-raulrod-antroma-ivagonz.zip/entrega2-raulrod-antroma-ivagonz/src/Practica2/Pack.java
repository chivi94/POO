package Practica2;

import java.util.ArrayList;

/**
 * Implementacion de un Pack de Producto. Se podra consultar su informacion.
 * 
 * Segunda parte de la practica para la asignatura de Programacion Orientada a
 * Objetos. Escuela de Ingenieria Informatica, Universidad de Valladolid.
 * 
 * @author raulrod antroma ivagonz
 *
 */
public class Pack extends Vendible {

	/**
	 * Constante que indica la cantidad maxima de productos que puede contener
	 * un Pack.
	 */
	public static final int CANTIDADMAXIMA = 9;
	private ArrayList<Producto> productos;
	private static ArrayList<String> identificadores = new ArrayList<String>();
	private String identificador;

	/**
	 * Inicializacion de pack con nombre, identificador, precio y los productos
	 * que lo forman.
	 * 
	 * @see Practica2.Vendible#Vendible(String nombre, String identificador)
	 * @param productos
	 *            Array de objetos Producto.
	 * @assert.pre productos.length mayor o igual a 2
	 * @assert.pre !producto.equals(productos[i])
	 * @assert.pre productos.length menor o igual que 9
	 * @assert.pre identificador.length() igual a 8
	 * @assert.pre !Pack.identificadores.contains(identficador)
	 */
	public Pack(String nombre, String identificador, Producto[] productos) {
		// TODO Auto-generated constructor stub
		super(nombre, identificador);
		assert (identificador.length() == 8);
		assert (!containsIdentificador(identificador));
		assert (comprobarCantidad(productos));
		assert (!productosRepetidos(productos));
		assert (productos.length <= CANTIDADMAXIMA);
		this.productos = volcar(productos);
		identificadores.add(identificador);

	}

	/**
	 * Comprueba que no existan productos repetidos dentro del mismo pack
	 * 
	 * @param productos
	 *            Array para realizar la comprobacion.
	 * @return true si hay repetidos, false si no hay repetidos
	 */
	public static boolean productosRepetidos(Producto[] productos) {
		for (int i = 0; i < productos.length; i++) {
			for (int j = 0; j < productos.length; j++) {
				if (productos[i].equals(productos[j]) && i != j) {
					return true;
				}
			}
		}
		return false;

	}

	/**
	 * Cuenta el numero de productos dentro de un pack
	 * 
	 * @return cantidad de productos dentro del pack
	 */
	public int cantidadProductos() {
		return productos.size();
	}

	/**
	 * Comprueba que la cantidad de productos sea mayor o igual a dos
	 * 
	 * @return true si la cantidad es correcta, false en su defecto
	 */
	public static boolean comprobarCantidad(Producto[] productos) {
		int contador = 0;
		for (int i = 0; i < productos.length; i++) {
			if (productos[i] != null) {
				contador++;
			}
		}
		if (contador >= 2) {
			return true;
		}
		return false;
	}

	/**
	 * Comprueba si un producto pertenece al pack
	 * 
	 * @param producto
	 *            que le pasamos para que compruebe
	 * @return true si el pack lo contiene, false en caso contrario
	 */
	public boolean containsProducto(Producto producto) {
		for (int i = 0; i < productos.size(); i++) {
			if (producto.equals(productos.get(i))) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Metodo para eliminar un producto contenido en un pack
	 * 
	 * @param producto
	 *            que deseamos eliminar del pack
	 * @assert.pre producto no nulo
	 * @assert.pre la cantidad del pack es mayor que 2
	 * @assert.pre el producto a quitar esta dentro del pack
	 */
	public void quitarProducto(Producto producto) {
		assert (producto != null);
		assert (cantidadProductos() > 2);
		assert (containsProducto(producto));
		for (int i = 0; i < productos.size(); i++) {
			if (producto.equals(productos.get(i))) {
				productos.remove(i);
			}
		}
	}

	/**
	 * Metodo para agregar un prodructo a un pack
	 * 
	 * @param producto
	 *            que deseamos agregar al pack
	 * @assert.pre producto no nulo
	 * @assert.pre la cantidad contenida en el pack es menor que el maximo
	 * @assert.pre el producto no esta contenido en el pack
	 */
	public void agregarProducto(Producto producto) {
		assert (producto != null);
		assert (cantidadProductos() < CANTIDADMAXIMA);
		assert (!containsProducto(producto));
		int i = 0;
		boolean encontrado = false;

		while (!encontrado && i < productos.size()) {
			if (productos.get(i) == null) {
				productos.add(producto);
				encontrado = true;
			}
			i++;
		}

	}

	private ArrayList<Producto> volcar(Producto[] productos) {
		ArrayList<Producto> a = new ArrayList<Producto>();
		for (int i = 0; i < productos.length; i++) {
			a.add(productos[i]);
		}
		return a;
	}

	/**
	 * Comprueba que el identificador de cada pack sea unico
	 * 
	 * @param id
	 *            identificador a comprobar
	 * @return true si el identificador ya existe, false en caso contrario
	 */
	public static boolean containsIdentificador(String id) {
		return identificadores.contains(id);
	}

	/**
	 * Lista que contiene todos los identificadores de los Packs creados.
	 */
	public static ArrayList<String> identificadores() {
		return identificadores;
	}

	/**
	 * @see Practica2.Vendible#getPrecio()
	 * @return suma de los precios del pack * 0.8
	 */
	@Override
	public double getPrecio() {
		// TODO Auto-generated method stub
		double suma = 0;
		for (int i = 0; i < productos.size(); i++) {
			suma += productos.get(i).getPrecio();
		}
		return 0.8 * suma;
	}

	/**
	 * @return lista de productos dentro del Pack.
	 */
	public Producto[] getProductos() {
		Producto[] p = new Producto[productos.size()];
		for (int i = 0; i < p.length; i++) {
			p[i] = productos.get(i);
		}
		return p;
	}

	/**
	 * @return identificador asociado al Pack.
	 */
	public String getIdentificador() {
		return identificador;
	}

	/**
	 * Crea un string a partir de los nombres de los productos contenidos en el
	 * pack
	 * 
	 * @return string con el nombre de los productos contenidos en el pack
	 */
	@Override
	public String toString() {
		String componentes = "";
		for (int i = 0; i < productos.size(); i++) {
			componentes += productos.get(i).getNombre() + "\n";
		}
		return componentes;
	}

}
