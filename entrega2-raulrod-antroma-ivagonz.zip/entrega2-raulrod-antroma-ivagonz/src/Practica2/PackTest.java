package Practica2;

import static org.junit.Assert.*;

import org.junit.Test;

public class PackTest {

	@Test (expected = AssertionError.class)
	public void test() {
		fail("Not yet implemented");
	}

}
