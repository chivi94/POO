package Practica2;

import static org.junit.Assert.*;

import org.junit.Test;

public class PackTest {

	// Pruebas del constructor
	// Validas
	@Test
	public void testConstructorCorrecto() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto[] array = new Producto[] { a, b };
		Pack p = new Pack("Pack1", "11111111", array);
		assertNotNull(p);
		assertEquals("Pack1", p.getNombre());
		assertEquals("11111111", p.getId());
		assertArrayEquals(array, p.getProductos());
	}

	// No Validas

	@Test(expected = IllegalArgumentException.class)
	public void testConstructorTodoCorrectoNombreNulo() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto[] array = new Producto[] { a, b };
		@SuppressWarnings("unused")
		Pack p = new Pack(null, "11111112", array);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstructorTodoCorrectoNombreCadenaVacia() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto[] array = new Producto[] { a, b };
		@SuppressWarnings("unused")
		Pack p = new Pack("", "11111113", array);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstructorTodoCorrectoIdNulo() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto[] array = new Producto[] { a, b };
		@SuppressWarnings("unused")
		Pack p = new Pack("Pack1", null, array);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstructorTodoCorrectoIdCadenaVacia() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto[] array = new Producto[] { a, b };
		@SuppressWarnings("unused")
		Pack p = new Pack("Pack1", "", array);
	}

	@Test(expected = AssertionError.class)
	public void testConstructorTodoCorrectoIdLongitudDistintoDe8() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto[] array = new Producto[] { a, b };
		@SuppressWarnings("unused")
		Pack p = new Pack("Pack1", "1111111", array);

	}

	@Test(expected = AssertionError.class)
	public void testConstructorTodoCorrectoProductosUnSoloProducto() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto[] array = new Producto[] { a };
		@SuppressWarnings("unused")
		Pack p = new Pack("Pack1", "11111115", array);

	}

	@Test(expected = AssertionError.class)
	public void testConstructorTodoCorrectoProductosVacio() {
		Producto[] array = new Producto[] {};
		@SuppressWarnings("unused")
		Pack p = new Pack("Pack1", "11111116", array);

	}

	@Test(expected = AssertionError.class)
	public void testConstructorTodoCorrectoProductosProductoRepetido() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto[] array = new Producto[] { a, a };
		@SuppressWarnings("unused")
		Pack p = new Pack("Pack1", "11111117", array);

	}

	// Pruebas para quitarProducto
	// Validas
	@Test
	public void testQuitarProductoValida() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto c = new Producto(3.0, "Cosa", "333333333331");
		Producto[] array = new Producto[] { a, b, c };
		Pack p = new Pack("Pack1", "11111118", array);
		p.quitarProducto(c);
		assertNotNull(c);
		assertFalse(p.cantidadProductos() > 2);
		assertFalse(p.containsProducto(c));

	}

	// No validas
	@Test(expected = AssertionError.class)
	public void testQuitarProductoProductoNulo() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto c = new Producto(3.0, "Cosa", "222222222224");
		Producto[] array = new Producto[] { a, b, c };
		Pack p = new Pack("Pack1", "11111119", array);
		p.quitarProducto(null);

	}

	@Test(expected = AssertionError.class)
	public void testQuitarProductoProductoNoContenido() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto c = new Producto(3.0, "Cosa", "222222222224");
		Producto d = new Producto(3.0, "Cosa", "333333333331");
		Producto[] array = new Producto[] { a, b, c };
		Pack p = new Pack("Pack1", "22222222", array);
		p.quitarProducto(d);

	}

	@Test(expected = AssertionError.class)
	public void testQuitarProductoPackMenosDeDosProductos() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto[] array = new Producto[] { a, b };
		Pack p = new Pack("Pack1", "22222221", array);
		p.quitarProducto(b);

	}

	// Pruebas para agregarProducto
	// Validas

	@Test
	public void testAgregarProductoValida() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto c = new Producto(3.0, "Gominola", "333333333331");
		Producto[] array = new Producto[] { a, b };
		Pack p = new Pack("Pack1", "22222223", array);
		p.agregarProducto(c);
		assertNotNull(c);
		assertTrue(p.cantidadProductos() < Pack.CANTIDADMAXIMA);
		assertFalse(p.containsProducto(c));

	}
	//Clases no validas
	@Test(expected = AssertionError.class)
	public void testAgregarProductoProductoNulo() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto[] array = new Producto[] { a, b };
		Pack p = new Pack("Pack1", "22222224", array);
		p.agregarProducto(null);
		

	}
	
	@Test(expected = AssertionError.class)
	public void testAgregarProductoProductoRepetido() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto c = new Producto(3.0, "Gominola", "333333333331");
		Producto[] array = new Producto[] { a, b, c };
		Pack p = new Pack("Pack1", "22222225", array);
		p.agregarProducto(c);
		

	}
	
	@Test(expected = AssertionError.class)
	public void testAgregarProductoPackLleno() {
		Producto a = new Producto(3.0, "KitKat", "111111111117");
		Producto b = new Producto(3.0, "Cosa", "123456789128");
		Producto c = new Producto(3.0, "Gominola", "333333333331");
		Producto d = new Producto(3.0, "Gominola", "444444444448");
		Producto e = new Producto(3.0, "Gominola", "555555555555");
		Producto f = new Producto(3.0, "Gominola", "666666666662");
		Producto g = new Producto(3.0, "Gominola", "777777777779");
		Producto h = new Producto(3.0, "Gominola", "888888888886");
		Producto i = new Producto(3.0, "Gominola", "999999999993");
		Producto j = new Producto(3.0, "Gominola", "222222222224");
		Producto[] array = new Producto[] { a, b, c, d, e, f, g, h, i};
		Pack p = new Pack("Pack1", "22222226", array);
		p.agregarProducto(j);
		

	}
}
