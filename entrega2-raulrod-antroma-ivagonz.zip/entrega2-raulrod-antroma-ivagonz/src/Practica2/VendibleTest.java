package Practica2;

import static org.junit.Assert.*;

import org.junit.Test;

public class VendibleTest {
	double error = 0.001;
	
	@Test
	public void testgetPrecioProductoPack() {
		Vendible v;
		Producto a = new Producto(3.0, "Cosa", "123456789128");
		Producto b = new Producto(2.0, "KitKat", "111111111117");
		Producto [] array =new Producto[] {a,b};
		Pack c = new Pack("Pack", "12345678", array);
		v = a;
		assertEquals(3.0, v.getPrecio(), error);
		v = c;
		assertEquals(4.0, v.getPrecio(), error);
		
	}
	
	@Test
	public void testGetPrecioPackModificandoPrecioProducto() {
		Vendible v;
		Producto a = new Producto(3.0, "Cosa", "123456789128");
		Producto b = new Producto(2.0, "KitKat", "111111111117");
		Producto [] array =new Producto[] {a,b};
		Pack c = new Pack("Pack", "12345678", array);
		v = a;
		assertEquals(3.0, v.getPrecio(), error);
		v = c;
		assertEquals(4.0, v.getPrecio(), error);
		double precioAntes = v.getPrecio();
		a.setPrecio(4.0);
		assertNotEquals(precioAntes,v.getPrecio(),error);
		
	}
	
	@Test
	public void testgetNombreProductoPack() {
		Vendible v;
		Producto a = new Producto(3.0, "Cosa", "123456789128");
		Producto b = new Producto(2.0, "KitKat", "111111111117");
		Producto [] array =new Producto[] {a,b};
		Pack c = new Pack("Pack", "12345678", array);
		v = a;
		assertEquals("Cosa",v.getNombre());
		v = c;
		assertEquals("Pack",v.getNombre());
		
	}
	
	@Test
	public void testgetIdProductoPack() {
		Vendible v;
		Producto a = new Producto(3.0, "Cosa", "123456789128");
		Producto b = new Producto(2.0, "KitKat", "111111111117");
		Producto [] array =new Producto[] {a,b};
		Pack c = new Pack("Pack", "12345678", array);
		v = a;
		assertEquals("123456789128",v.getId());
		v = c;
		assertEquals("12345678",v.getId());
		
	}
	
	@Test
	public void testequalsProductoPack() {
		Vendible v;
		Vendible w;
		Producto a = new Producto(3.0, "Cosa", "123456789128");
		Producto b = new Producto(2.0, "KitKat", "111111111117");
		Producto [] array =new Producto[] {a,b};
		Pack c = new Pack("Pack", "12345678", array);
		v = a;
		w = c;
		assertTrue(!w.equals(v));
		assertTrue(w.equals(w));
	}
	
	

}
