package Practica1;

import fabricante.externo.tarjetas.TarjetaMonedero;

/**
 * Implementación de un Producto. Se podrá consultar su información.
 * 
 * Primera parte de la práctica para la asignatura de Programación Orientada a
 * Objetos. Escuela de Ingeniería Informática, Universidad de Valladolid.
 * 
 * @author raulrod antroma ivagonz
 * 
 */

public class Producto {
	private double precio;
	private String nombre;
	private int upc;

	/**
	 * * Inicializa un Producto con los argumentos indicados a continuación.
	 * 
	 * 
	 * @param precio
	 * @param nombre
	 * @param upc
	 */
	public Producto(double precio, String nombre, int upc) {
		
		assert precio > 0; 
		this.precio = precio;
		this.nombre = nombre;
		this.upc = upc;
	}
}
